function phz = phasescreen2(M, delta, L0, l0, wavelength, Cn, delta_x, delta_y, delta_z)
    % Set up the frequency grid
    del_k = 2 * pi / (M * delta);            % Frequency grid spacing [1/m]
    kx = (-M/2 : M/2-1) * del_k;             % Frequency grid [1/m]
    [kx, ky] = meshgrid(kx, kx);             % Create a 2D frequency grid

    % Calculate the phase screen in the frequency domain

    % Compute C_tilde using nested for loops
    C_tilde = zeros(M, M);

    % Random phase offset parameters
    constant_value_kx = (randn - 0.5) * del_k;  % Generate a single random value
    
    delta_kx = constant_value_kx * ones(M, M);  % Assign the constant value to all points
    delta_ky = delta_kx;  % Assign the constant value to all points
    a = randn(M, M);  % Real part (Gaussian distributed)
    b = randn(M, M);  % Imaginary part (Gaussian distributed)
    
    % Combine 'a' and 'b' to form the complex matrix 'z'
    z = a + 1i * b;
    for i = 1:M
        for j = 1:M
            % Calculate the value for each (i, j) element
            C_tilde(i, j) = z(i,j) * ...
                sqrt(2 * pi * delta_z * del_k^2 * computePhi_n(kx(i, j) + delta_kx(i,j), ky(i, j) + delta_ky(i,j), l0, L0, Cn)) * ...
                                                                 (2 * pi / wavelength);
        end
    end

    % Compute the inverse FFT to get the phase screen in the spatial domain
    C = M^2 * ifft2(C_tilde);

    % Initialize theta_R matrix
    [m, n] = size(C);  % Get the size of matrix C
    theta_R = zeros(m, n);  % Initialize theta_R with the same size as C
    
    % Calculate theta_R
    for i = 1:m
        for j = 1:n
            theta_R(i, j) = exp(1i * ((i-1) * delta_x * delta_kx(i,j) + (j-1) * delta_y * delta_ky(i,j))) * C(i, j);
        end
    end

    % Return the phase screen (optional: theta_R or C can be returned)
    phz = theta_R;

end
