%Parameters
N = 1024;    % Number of grid points
delta = 1; % Grid spacing [m]
L0 = 1000.0; % Outer scale [m]
l0 = 10;  % Inner scale [m]
delta_x = delta;
delta_y = delta;
wavelength = 5e-7;
Cn = 1e-14;
M_values = [512, 1024, 2048];

% Define parameters for phase screen generation
num_trials = 500;           % Reduced trial count for computational efficiency
E_randomized = zeros(num_trials, length(M_values)); % Placeholder for RMS error data
central_phase_samples = zeros(num_trials, length(M_values));
phase_diff_x_samples = zeros(num_trials, length(M_values));
phase_diff_y_samples = zeros(num_trials, length(M_values));

% Loop over grid sizes and calculate RMS error for each
for grid_idx = 1:length(M_values)
    M = M_values(grid_idx);
    phase_errors = zeros(num_trials, 1);
    
    for trial = 1:num_trials
        % Step 1: Generate random phase screen
        phase_screen = phasescreen2(M, delta, L0, l0, wavelength, Cn, delta_x, delta_y);
        
        % Log key parameters
        center_phase = phase_screen(M/2, M/2);
        
        % Store central phase and phase differences for each trial
        central_phase_samples(trial, grid_idx) = center_phase;
    end
end

% Plotting the result
disp(abs(central_phase_samples(:)))
figure;

hist_values = histogram(real(central_phase_samples(:)), 'Normalization', 'pdf'); % Normalizing the PDF

title('Distribution of Central Phase Samples');
xlabel('Central Phase');
ylabel('Probability Density');
