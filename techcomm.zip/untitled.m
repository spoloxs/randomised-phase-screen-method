function D = str_fcn2_ft(ph, mask, delta)
% STR_FCN2_FT computes the structure function using Fourier transforms.
% Inputs:
%   ph    - The phase matrix (2D array).
%   mask  - The mask matrix (2D array) to isolate specific regions.
%   delta - The spacing between points in the phase matrix.
% Output:
%   D     - The computed structure function.

% Get the size of the input matrix
N = size(ph, 1);

% Apply the mask to the phase matrix
ph = ph .* mask;

% Compute Fourier transforms of the phase and related terms
P = fft2(ph) * delta^2;         % Fourier transform of the phase matrix, scaled by delta^2
S = fft2(ph.^2) * delta^2;      % Fourier transform of the squared phase matrix, scaled by delta^2
W = fft2(mask) * delta^2;       % Fourier transform of the mask, scaled by delta^2

% Frequency resolution
delta_f = 1 / (N * delta);

% Compute the inverse Fourier transform of the squared mask transform
w2 = ifft2(W .* conj(W)) * (N * delta_f)^2; % Normalization using the inverse FT, scaled by (N * delta_f)^2

% Compute the structure function using inverse Fourier transforms
D = 2 * ifft2(real(S .* conj(W)) - abs(P).^2) * (N * delta_f)^2 ./ w2 .* mask; % Scaled by (N * delta_f)^2
end

% Constants
M = 2048;                       % Grid size
Mask = ones(M, M);             % Mask (modifiable)
L0 = 1000;                   % Outer scale (100 km) in m
l0 = 0.01;                        % Inner scale (1 cm)
rho_o = 0.05;                     % Effective coherence length (5 cm)
Cn = 1e-7;                     % Refractive index structure constant
delta = 0.0001;                 % Grid spacing (cm)
wavelength = 5e-7;             % Wavelength (cm)
delta_x = delta;               % Grid spacing in x-direction
delta_y = delta;               % Grid spacing in y-direction
delta_z = 64;                   % Grid spacing in z-direction

% Calculate rho points
rho_points = 1:M/2;            % Only the first half of the grid

% Derived constants
kappa_l = 3.3 / l0;
kappa_0 = 2 * pi / L0;

% Function for fn(x)
fn = @(x) 1 + 1.802 * x - 0.254 * x.^(7/6);

% Phin function (element-wise operations)
phin = @(kappa) 0.033 * Cn^2 * fn(kappa / kappa_l) .* exp(-kappa.^2 / kappa_l^2) ./ (kappa.^2 + kappa_0^2).^(11/6);

% Generate phase screens
phz1 = real(phasescreen2(M, delta, L0, l0, wavelength, Cn, delta_x, delta_y, delta_z));
D1_x_y = str_fcn2_ft(phz1, Mask, delta);

phz2 = real(phasescreen(M, delta, L0, l0, wavelength, Cn, delta_z));
D2_x_y = str_fcn2_ft(phz2, Mask, delta);

% Initialize D1_rho and D2_rho
D1_rho = zeros(M/2, 1);
D2_rho = zeros(M/2, 1);

% Extract D1 and D2 values (assuming diagonal elements)
for i = 1:M/2
    D1_rho(i) = D1_x_y(i, i);
    D2_rho(i) = D2_x_y(i, i);
end

% Integration limits and grid setup
kappa_rho_max = 100;           % Upper limit for integration
kappa_rho_points = 1000;       % Number of points for integration

% Initialize D_theta_rho
D_theta_rho = zeros(size(rho_points));

% Numerical integration using trapezoidal rule for each rho
for i = 1:length(rho_points)
    rho = rho_points(i)*delta;
    kappa_rho_values = linspace(0, kappa_rho_max, kappa_rho_points);
    integrand = @(kappa_rho) 8 * pi^2 * (2 * pi / wavelength)^2 * delta_z * kappa_rho .* phin(kappa_rho) .* (1 - besselj(0, rho * kappa_rho));
    D_theta_rho(i) = integral(integrand, 0, Inf); 
end

% Plot all three data sets on the same figure with logarithmic y-axis
figure;
loglog(rho_points .* delta, D_theta_rho, 'LineWidth', 1.5, 'DisplayName', 'D_\theta(\rho)');
hold on;
loglog(rho_points .* delta, D1_rho, 'LineWidth', 1.5, 'DisplayName', 'D1_\theta(\rho)');
loglog(rho_points .* delta, D2_rho, 'LineWidth', 1.5, 'DisplayName', 'D2_\theta(\rho)');
hold off;

% Customize the plot
xlabel('\rho (cm)');
ylabel('D(\rho)');
title('Combined Plot of D_\theta(\rho), D1_\theta(\rho), and D2_\theta(\rho) with Logarithmic Scale');
legend('show');
grid on;
